//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 14/04/22.
//

import Foundation
import SwiftUI

struct MLResponseView: View{
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [
        NSSortDescriptor(keyPath: \MyZoo.index, ascending: true)
    ], animation: .default)
    private var items: FetchedResults<MyZoo>
    
    @Binding var isPresenting: Bool
    @Binding var uiImage: UIImage?
    @State var classificationLabel: String = ""
    @State var tmpAnimal: Animal = Animal()
    var imagePredictor = ImagePredictor()
    @State var sourceType: UIImagePickerController.SourceType = .camera
    
    private func saveItem(animalName: String) async throws -> Void {
        let myZoo = MyZoo(context: viewContext)
        myZoo.name = animalName
        myZoo.index = items.count + 1
        myZoo.habitat = tmpAnimal.habitat
        myZoo.posx = 0
        myZoo.posy = 0
        myZoo.negMovX = false
        myZoo.negMovY = false
        myZoo.animation = 0
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    private func classifyImage(_ image: UIImage){
        do {
            
            try self.imagePredictor.makePredictions(for: image){ prediction in
                self.classificationLabel = "We are sorry but we weren't able to recognize your object"
                guard let prediction = prediction else {
                    self.classificationLabel = "No predictions. (Check console log.)"
                    return
                }
                if !prediction.isEmpty {
                    self.classificationLabel = prediction.first!.classification
                    tmpAnimal = animal.first(where: {$0.name == classificationLabel}) ?? Animal()
                }else{
                    self.classificationLabel = "We are sorry but we weren't able to recognize your object"
                }
            }
        } catch {
            print("Vision was unable to make a prediction...\n\n\(error.localizedDescription)")
        }
    }
    
    var body: some View{
        NavigationView{
            ZStack{
                Color.init(red: 20/255, green: 71/255, blue: 82/255).ignoresSafeArea()
                VStack{
                    if classificationLabel != "" {
                        Text("It's a "+classificationLabel)
                            .font(Font.largeTitle)
                            .bold()
                            .foregroundColor(Color.orange)
                        
                        Image("\(classificationLabel) 1")
                    }
                    else {
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: (Color.orange)))
                            .onAppear(perform: {
                                Task {
                                    classifyImage(uiImage ?? UIImage())
                                    
                                    if (items.first(where: {$0.name == classificationLabel}) == nil){
                                        try await saveItem(animalName: classificationLabel)
                                    }
                                }
                            })
                    }
                    
                }
            }
        }
    }
}
