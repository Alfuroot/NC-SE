//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 17/04/22.
//

import Foundation
import SwiftUI

struct DescriptionView: View {
    
    @Binding var name: String
    
    var body: some View {
        GeometryReader{geometry in
            ZStack{
                Color.init(red: 20/255, green: 71/255, blue: 82/255).ignoresSafeArea()
                VStack{
                    Image("\(name) 1")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width*0.1, height: geometry.size.height*0.1)
                    
                    Text("Habitat: \(animal.first(where: {$0.name == name})?.habitat ?? "")")
                        .font(Font.body)
                        .bold()
                        .foregroundColor(Color.orange)
                        .padding(.horizontal)
                    HStack{
                        
                        
                        Text("\(animal.first(where: {$0.name == name})?.description ?? "")")
                            .font(Font.body)
                            .bold()
                            .foregroundColor(Color.orange)
                            .padding(.horizontal)
                        
                        
                    }
                }
            }
        }
    }
}
