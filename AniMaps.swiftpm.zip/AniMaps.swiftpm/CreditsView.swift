//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 24/04/22.
//

import Foundation
import SwiftUI

struct CreditsView: View {
    var body: some View {
        ZStack{
            Color.init(red: 20/255, green: 71/255, blue: 82/255).ignoresSafeArea()
            VStack{
                Spacer()
                Text(.init("Animals PNGs credits: \n https://thkaspar.itch.io"))
                
                    .font(Font.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color.orange)
                Spacer()
                Text(.init("Map components credits: \n https://game-endeavor.itch.io"))
                    .font(Font.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color.orange)
                Spacer()
            }
        }
    }
}
