import SwiftUI

struct ContentView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [
        NSSortDescriptor(keyPath: \MyZoo.index, ascending: true)
    ], animation: .default)
    
    private var items: FetchedResults<MyZoo>
    
    
    var body: some View {
        NavigationView{
            ZStack{
                Color.init(red: 20/255, green: 71/255, blue: 82/255).ignoresSafeArea()
            VStack {
                Spacer()
                Image("Logo")
                Spacer()
                NavigationLink(destination: DashBoardView(), label: {
                    Text("TAP TO START")
                        .font(Font.largeTitle)
                        .bold()
                        .foregroundColor(Color.orange)
                })
                Spacer()
            }
            }
            
        }.navigationViewStyle(.stack)
            
        
        
    }
    private func saveItem(animalName: String){
        let myZoo = MyZoo(context: viewContext)
        myZoo.name = animalName
        myZoo.index = items.count + 1
        myZoo.posx = 0
        myZoo.posy = 0
        myZoo.negMovX = false
        myZoo.negMovY = false
        myZoo.animation = 0
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    private func delete(at offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)
            
            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}
