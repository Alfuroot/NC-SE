//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 15/04/22.
//

import CoreData
import SwiftUI

@objc(MyZoo)
class MyZoo: NSManagedObject {
    @NSManaged var name: String?
    @NSManaged var index: Int
    @NSManaged var posx: Float
    @NSManaged var posy: Float
    @NSManaged var animation: Int
    @NSManaged var habitat: String
    @NSManaged var negMovX: Bool
    @NSManaged var negMovY: Bool
}

extension MyZoo: Identifiable {
    var id: Int {
        index
    }
}

enum habitats {
    case savana
    case forest
    case thundra
}
