//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 21/04/22.
//

import Foundation

struct Animal: Identifiable, Decodable {
    var id: String
    var name: String
    var habitat: String
    var description: String
    
    init(){
        self.id = ""
        self.name = ""
        self.habitat = ""
        self.description = ""
    }
}
