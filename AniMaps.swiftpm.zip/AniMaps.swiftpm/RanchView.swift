//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 18/04/22.
//

import Foundation
import SwiftUI

struct RanchView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [
        NSSortDescriptor(keyPath: \MyZoo.index, ascending: true)
    ], animation: .default)
    private var items: FetchedResults<MyZoo>
    
    @Binding var habitat: String
    @Binding var isPresenting: Bool
    @State var showCredits: Bool = false
    @State var tmpName: String = ""
    @State var showDescription: Bool = false
    
    func checkBorder(geometry: GeometryProxy, item: MyZoo){
        
        if item.posx <= Float(geometry.size.width * 0.05){
            item.negMovX = false
        }
        else if item.posx >= Float(geometry.size.width * 0.95){
            item.negMovX = true
        }
        
        if item.posy <= Float(geometry.size.height * 0.05){
            item.negMovY = false
        }
        else if item.posy >= Float(geometry.size.height * 0.9){
            item.negMovY = true
        }
        if item.posx <= Float(geometry.size.width * 0.7) && item.posx >= Float(geometry.size.width*0.25) && item.posy >= Float(geometry.size.height*0.3) && item.posy <= Float(geometry.size.height*0.7){
            if item.posx <= Float(geometry.size.width*0.5){
                item.negMovX = true
            } else {item.negMovX = false}
            if item.posy <= Float(geometry.size.height*0.5){
                item.negMovY = true
            }
            else {item.negMovY = false}
        }
    }
    
    func moveAnimal(geometry: GeometryProxy, item: MyZoo){
        if item.negMovY {
            item.posy -= 10
        }
        else {
            item.posy += 10
        }
        
        if item.negMovX {
            item.posx -= 10
        }
        else {
            item.posx += 10
        }
    }
    
    var body: some View {
        GeometryReader{geometry in
            
            Image("Forest")
                
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.top)
            
            ZStack{
                ForEach (items) {item in
                    if item.habitat == habitat {
                        Image("\(item.name ?? "not found")"+" \(item.animation)")
                        
                            .resizable()
                            .frame(width: geometry.size.width*0.05, height: geometry.size.width*0.05)
                            .scaledToFit()
                            .position(x: CGFloat(item.posx), y: CGFloat(item.posy))
                            .onAppear(perform: {
                                if item.animation != 1 {
                                    item.animation = 1
                                }
                                else {
                                    item.animation += 1
                                }
                                item.posx = Float.random(in: 10...Float(geometry.size.width*0.95))
                                item.posy = Float.random(in: 10...Float(geometry.size.height*0.9))
                                if item.posx <= Float(geometry.size.width * 0.7) && item.posx >= Float(geometry.size.width*0.25) && item.posy >= Float(geometry.size.height*0.3) && item.posy <= Float(geometry.size.height*0.7){
                                    item.posx = Float(geometry.size.width*0.5)
                                    item.posy = Float(geometry.size.height*0.8)
                                }
                            })
                            .onChange(of: item.animation, perform: {_ in
                                if item.animation <= 3 {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(100)) {
                                        item.animation +=  1
                                        checkBorder(geometry: geometry, item: item)
                                        moveAnimal(geometry: geometry, item: item)

                                    }
                                }
                                else {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(100)) {
                                        item.animation = 1
                                    }
                                }
                            })
                            .onTapGesture(perform: {
                                showDescription = true
                                tmpName = item.name ?? "Error"
                            })
                        
                    }
                }
                Button(action: {
                    isPresenting = true
                }, label: {
                    Image("Camera")
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width*0.1, height: geometry.size.height*0.1)
                        
                }).position(x: geometry.size.width*0.5, y: geometry.size.height*0.92)
                Image(systemName: "info.circle")
                    .position(x: geometry.size.width*0.95, y: geometry.size.height*0.98)
                    .foregroundColor(Color.white)
                    .onTapGesture {
                        showCredits = true
                    }
            }.sheet(isPresented: $showDescription, onDismiss: { showDescription = false }){
                DescriptionView(name: $tmpName)
            }
            .sheet(isPresented: $showCredits, onDismiss: {
                showCredits = false
            }){
                CreditsView()
            }
           
        }
    }
    
}
