//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 21/04/22.
//

import Foundation
import SwiftUI

struct BestiaryView: View{
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [
        NSSortDescriptor(keyPath: \MyZoo.index, ascending: true)
    ], animation: .default)
    private var items: FetchedResults<MyZoo>
    
    init() {
        UITableView.appearance().separatorStyle = .none
        UITableView.appearance().backgroundColor = UIColor(Color.init(red: 20/255, green: 71/255, blue: 82/255))
        UITableViewCell.appearance().backgroundColor = UIColor(Color.init(red: 20/255, green: 71/255, blue: 20/255))
    }
    
    var body: some View{
        ZStack{
            
            VStack{
                List{
                    ForEach (items) {item in
                        Section{
                            HStack{
                                Image("\(item.name ?? "") 1")
                                Text(item.name ?? "not found")
                                    .font(Font.body)
                                    .bold()
                                    .foregroundColor(Color.orange)
                                
                            }
                        }
                    }
                    
                }
            }
        }
        
    }
}
