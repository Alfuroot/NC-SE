//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 14/04/22.
//

import Foundation
import SwiftUI

struct DashBoardView: View{
    
    init() {
        UITabBar.appearance().backgroundColor = UIColor(Color.init(red: 20/255, green: 71/255, blue: 40/255))
        UITabBar.appearance().unselectedItemTintColor = UIColor.white.withAlphaComponent(0.6)
        
    }
    
    @State var closeCamera: Bool = false
    @State var habitat: String = "Forest"
    @State var showDescription: Bool = false
    @State var isPresenting: Bool = false
    @State var uiImage: UIImage?
    @State var gotResult: Bool = false
    @State var sourceType: UIImagePickerController.SourceType = .camera
    
    var body: some View{
        GeometryReader{geometry in
            ZStack{
                
                
                TabView{
                    RanchView(habitat: $habitat, isPresenting: $isPresenting)
                        .tabItem{
                            Label("Zoo", systemImage: "pawprint.circle")
                            Text("Zoo")
                        }
                    BestiaryView()
                        .tabItem{
                            Label("Bestiary", systemImage: "book.closed.circle")
                            Text("Bestiary")
                        }
                }.accentColor(Color.orange)
                    .navigationBarBackButtonHidden(true)
                
            }.navigationBarHidden(true)
                .fullScreenCover(isPresented: $isPresenting){
                    ZStack{
                        
                        Camera(uiImage: $uiImage, isPresenting: $isPresenting, gotResult: $gotResult)
                        
                    }.sheet(isPresented: $gotResult,onDismiss: {
                        isPresenting = false}, content: {
                            MLResponseView(isPresenting: $isPresenting, uiImage: $uiImage)
                        })
                    
                }
        }
    }
}
