//
//  File.swift
//  AniMaps
//
//  Created by Giuseppe Carannante on 15/04/22.
//

import CoreData
import SwiftUI

class Persistence {
    static let shared = Persistence()
    
    let container: NSPersistentContainer
    
    init(inMemory: Bool = false) {
        
        let myZooEntity = NSEntityDescription()
        myZooEntity.name = "MyZoo"
        myZooEntity.managedObjectClassName = "MyZoo"
        
        let nameAttribute = NSAttributeDescription()
        nameAttribute.name = "name"
        nameAttribute.type = .string
        myZooEntity.properties.append(nameAttribute)
        
        let indexAttribute = NSAttributeDescription()
        indexAttribute.name = "index"
        indexAttribute.type = .integer64
        myZooEntity.properties.append(indexAttribute)
        
        let posxAttribute = NSAttributeDescription()
        posxAttribute.name = "posx"
        posxAttribute.type = .float
        myZooEntity.properties.append(posxAttribute)
        
        let posyAttribute = NSAttributeDescription()
        posyAttribute.name = "posy"
        posyAttribute.type = .float
        myZooEntity.properties.append(posyAttribute)
        
        let animationAttribute = NSAttributeDescription()
        animationAttribute.name = "animation"
        animationAttribute.type = .integer64
        myZooEntity.properties.append(animationAttribute)
        
        let habitatAttribute = NSAttributeDescription()
        habitatAttribute.name = "habitat"
        habitatAttribute.type = .string
        myZooEntity.properties.append(habitatAttribute)
        
        let negMovXAttribute = NSAttributeDescription()
        negMovXAttribute.name = "negMovX"
        negMovXAttribute.type = .boolean
        myZooEntity.properties.append(negMovXAttribute)
        
        let negMovYAttribute = NSAttributeDescription()
        negMovYAttribute.name = "negMovY"
        negMovYAttribute.type = .boolean
        myZooEntity.properties.append(negMovYAttribute)
        
        let model = NSManagedObjectModel()
        model.entities = [myZooEntity]
        
        let container = NSPersistentContainer(name: "MyZooModel", managedObjectModel: model)
        
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        
        container.loadPersistentStores { description, error in
            if let error = error {
                fatalError("failed with: \(error.localizedDescription)")
            }
        }
        
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        container.viewContext.automaticallyMergesChangesFromParent = true
        self.container = container
    }
}
